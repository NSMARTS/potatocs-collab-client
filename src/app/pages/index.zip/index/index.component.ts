import { Component, HostListener, Renderer2, OnInit } from '@angular/core';
import AOS from 'aos'; //AOS - 1
import Swiper from 'swiper';

@Component({
    selector: 'app-index',
    templateUrl: './index.component.html',
    styleUrls: ['./index.component.scss'],
})
export class IndexComponent implements OnInit {
    // header
    isHeaderActive: boolean = false;
    prevScrollTop: number = 0;

    // topbutton
    showScrollButton = false;

    // constructor(private renderer: Renderer2) {}

    ngOnInit(): void {
        this.initAOS();

        this.initializeSwiper();
    }

    initializeSwiper() {
        new Swiper('.swiper-container', {
            slidesPerView: 1,
            loop: true,
            autoplay: {
                delay: 3000, // 슬라이드 간 간격 (밀리초 단위)
                disableOnInteraction: false, // 사용자의 인터랙션으로 인해 자동 재생을 중지하지 않습니다.
            },
            navigation: {
                nextEl: '.swiper-button-next', // 다음 버튼 요소를 추가할 DOM 요소를 지정합니다.
                prevEl: '.swiper-button-prev', // 이전 버튼 요소를 추가할 DOM 요소를 지정합니다.
            },
        });
    }

    initAOS(): void {
        setTimeout(() => {
            AOS.init({
                duration: 600,
                once: false,

                // 사용자 정의 애니메이션을 위한 옵션 추가
                useClassNames: true,
                initClassName: 'aos-init',
                animatedClassName: 'aos-animate',
                customClassName: 'fade-in-custom', // 사용자 정의 애니메이션 클래스명
            });
        }, 400);
    }

    // 탑버튼
    scrollToTop(): void {
        window.scrollTo({
            top: 0,
            behavior: 'smooth',
        });
    }

    @HostListener('window:scroll', ['$event'])
    onScroll(event) {
        const nowScrollTop = window.scrollY || document.documentElement.scrollTop || 0;

        if (nowScrollTop > this.prevScrollTop) {
            this.isHeaderActive = true;
        } else {
            this.isHeaderActive = false;
        }

        this.showScrollButton = nowScrollTop >= 500;

        this.prevScrollTop = nowScrollTop;
    }
}
